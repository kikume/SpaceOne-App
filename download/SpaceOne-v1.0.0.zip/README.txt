═══════════════════════════════════════════════
  SpaceOne — Local seed phrase vault
═══════════════════════════════════════════════

HOW TO USE (2 steps):

  1. Extract this ZIP to any folder
  2. Double-click the file:  index.html

The app opens in your browser and runs 100% on
your computer — nothing is sent to the internet.

FIRST USE:
  • Create your vault password (write it down:
    for security, there is NO password recovery)
  • Store your seed phrases, or generate 12 new
    words in the BIP39 standard

TIPS:
  • Use the "Backup" button to export an
    encrypted file of your seeds — it is your
    insurance if this computer ever breaks
  • The vault is saved in the browser you use to
    open index.html; always use the same one

Open source: github.com/kikume/SpaceOne-App
═══════════════════════════════════════════════
