═══════════════════════════════════════════════
  SpaceOne — Local seed phrase vault
═══════════════════════════════════════════════

HOW TO USE (2 steps):

  1. Extract this ZIP to any folder
     (right-click → Extract All…)
  2. Double-click:  SpaceOne App.html

The app opens in your browser and runs 100% on
your computer — nothing is sent to the internet.

IMPORTANT: extract before opening. If you open
the file from inside the ZIP, the app will ask
you to extract it first.

FIRST USE:
  • Create your vault password (write it down:
    for security, there is NO password recovery)
  • Store your seed phrases, or generate 12 new
    words in the BIP39 standard

TIPS:
  • Use the "Backup" button to export an
    encrypted file of your seeds — it is your
    insurance if this computer ever breaks
  • The vault is saved in the browser you use to
    open it; always use the same browser
  • Keep the folder in its final place before
    creating your vault (moving it later starts
    an empty vault — your backup restores it)

Open source: github.com/kikume/SpaceOne-App
═══════════════════════════════════════════════
